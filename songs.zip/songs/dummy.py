import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "songs.settings")
import django
django.setup()
from django.db import connection
with connection.cursor() as cursor:
    cursor.execute("DROP TABLE IF EXISTS app_song;")