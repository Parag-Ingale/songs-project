from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.contrib.auth.models import User
from rest_framework_simplejwt.tokens import RefreshToken
from .serializers import RegisterSerializer, LoginSerializer, SongSerializer
from rest_framework.permissions import AllowAny
from django.shortcuts import render, get_object_or_404
from django.core.paginator import Paginator
from django.views import View
from .models import SongTable
import pandas as pd
import json

class RegisterView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()

            tokens = RefreshToken.for_user(user)

            return Response({
                "message": "User registered!",
                "access": str(tokens.access_token),
                "refresh": str(tokens)
            }, status=status.HTTP_201_CREATED)

        
class LoginView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = LoginSerializer(data=request.data)

        if serializer.is_valid():
            return Response(serializer.validated_data, status=status.HTTP_200_OK)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    

class UploadSongData(View):
    template_name = "app/upload.html"

    def get(self, request):
        return render(request, self.template_name)
    
    def post(self, request):
        data = request.FILES.get("json_file")
        json_string = data.read().decode("utf-8")
        data = json.loads(json_string)

        df = pd.DataFrame(data)
        success, error = [], []

        for _, row in df.iterrows():
            serializer = SongSerializer(data=row.to_dict())
            if serializer.is_valid():
                serializer.save()
                success.append(row)
            else:
                error.append({"data": row, "errors": serializer.errors})
                
        return render(request, self.template_name,{"success": success, "error": error})
    
class SongsList(View):
    def get(self, request):
        title = request.GET.get("title")

        if title:
            song = SongTable.objects.get(title=title)
            return render(request, "app/song_details.html", {"song": song})
            
        songs = SongTable.objects.all().order_by("id")
        page_size = 20
        page_number = request.GET.get("page", 1)
        paginator = Paginator(songs, page_size)
        page_obj = paginator.get_page(page_number)
        print(page_obj.object_list)
        context = {
            "page_obj": page_obj,        
            "songs": page_obj.object_list, 
        }

        return render(request, "app/songs_list.html", context)
