from django.contrib.auth.models import User
from .models import SongTable
from rest_framework import serializers
from django.contrib.auth import authenticate
from rest_framework_simplejwt.tokens import RefreshToken

class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)

    class Meta:
        model = User
        fields = ['username', 'email', 'password']

    def create(self, validated_data):
        return User.objects.create_user(
            username=validated_data['username'],
            email=validated_data.get('email', ''),
            password=validated_data['password']
        )
    
class LoginSerializer(serializers.ModelSerializer):
    username = serializers.CharField()
    password = serializers.CharField(write_only=True)

    def validate(self, data):
        user = authenticate(
            username=data["username"],
            password=data["password"]
        )
        if not user:
            raise serializers.ValidationError("Invalid username or password")
        
        tokens = RefreshToken.for_user(user)

        return {
            "user_id": user.id,
            "username": user.username,
            "access": str(tokens.access_token),
            "refresh": str(tokens)
        }
    
class SongSerializer(serializers.ModelSerializer):
    class Meta:
        model = SongTable
        fields = '__all__'
        write_only_fields = ['id']
