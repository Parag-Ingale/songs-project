from django.urls import path
from .views import RegisterView, LoginView, UploadSongData, SongsList

urlpatterns = [
    path('register/', RegisterView.as_view(), name="register"),
    path('login/', LoginView.as_view(), name="login"),
    path("upload-song/", UploadSongData.as_view(), name="upload_songs"),
    path("list-songs/", SongsList.as_view(), name="list_songs")
]

