from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from decimal import Decimal

class SongTable(models.Model):
    id = models.CharField(primary_key=True, max_length=200)
    title = models.CharField(max_length=100, unique=True, blank=False)
    dance_ability = models.DecimalField(max_digits=10, decimal_places=5)
    energy = models.DecimalField(max_digits=10, decimal_places=5)
    model = models.IntegerField()
    acoustiness = models.DecimalField(max_digits=10, decimal_places=5)
    tempo = models.DecimalField(max_digits=10, decimal_places=5)
    duration_ms = models.IntegerField()
    num_segment = models.IntegerField()
    num_section = models.IntegerField()
    rating = models.DecimalField(
        max_digits=3,
        decimal_places=2,
        default=Decimal("0.00"),
        validators=[
            MinValueValidator(0.00),
            MaxValueValidator(5.00)
        ]
    )

    def __str__(self):
        return self.title

