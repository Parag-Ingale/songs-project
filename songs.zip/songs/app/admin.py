from django.contrib import admin
from .models import SongTable

admin.site.register(SongTable)
